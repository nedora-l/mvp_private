// Content script that runs on web pages to detect login forms

// Function to extract domain from current URL
function extractDomain(url) {
    const a = document.createElement('a');
    a.href = url;
    return a.hostname;
  }
  
  // Function to detect login forms on the page
  function detectLoginForms() {
    // Common selectors for username/email fields
    const usernameSelectors = [
      'input[type="email"]',
      'input[type="text"][name*="email"]',
      'input[type="text"][name*="user"]',
      'input[type="text"][id*="email"]',
      'input[type="text"][id*="user"]',
      'input[name="username"]',
      'input[id="username"]'
    ];
    
    // Check if any login fields exist on the page
    const potentialUsernameFields = [];
    
    usernameSelectors.forEach(selector => {
      const fields = document.querySelectorAll(selector);
      fields.forEach(field => potentialUsernameFields.push(field));
    });
    
    if (potentialUsernameFields.length > 0) {
      // We found potential login fields, notify the background script
      const domain = extractDomain(window.location.href);
      
      chrome.runtime.sendMessage(
        { action: "checkCredentials", domain: domain },
        (response) => {
          if (response && response.success && response.credentials.length > 0) {
            // If credentials exist for this domain, show notification
            showCredentialNotification(response.credentials, potentialUsernameFields[0]);
          }
        }
      );
    }
  }
  
  // Function to show a notification with available credentials
  function showCredentialNotification(credentials, targetField) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'daws-password-manager-notification';
    notification.innerHTML = `
      <div class="daws-notification-header">
        <img src="${chrome.runtime.getURL('icons/icon48.png')}" alt="DAWS Password Manager">
        <h3>DAWS Password Manager</h3>
        <button class="daws-close-btn">×</button>
      </div>
      <div class="daws-notification-content">
        <p>${credentials.length} saved account${credentials.length > 1 ? 's' : ''} found for this website:</p>
        <ul class="daws-credential-list">
          ${credentials.map(cred => `
            <li class="daws-credential-item" data-username="${cred.username}">
              <span>${cred.title}</span>
              <span class="daws-username">${cred.username}</span>
              <button class="daws-fill-btn">Fill</button>
            </li>
          `).join('')}
        </ul>
      </div>
    `;
    
    // Add styles
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.width = '300px';
    notification.style.backgroundColor = '#fff';
    notification.style.borderRadius = '8px';
    notification.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.15)';
    notification.style.zIndex = '9999';
    notification.style.fontFamily = 'Arial, sans-serif';
    notification.style.fontSize = '14px';
    notification.style.border = '1px solid #ddd';
    
    // Add to page
    document.body.appendChild(notification);
    
    // Close button handler
    const closeBtn = notification.querySelector('.daws-close-btn');
    closeBtn.addEventListener('click', () => {
      document.body.removeChild(notification);
    });
    
    // Fill credential handlers
    const credentialItems = notification.querySelectorAll('.daws-credential-item');
    credentialItems.forEach(item => {
      const fillBtn = item.querySelector('.daws-fill-btn');
      fillBtn.addEventListener('click', () => {
        const username = item.getAttribute('data-username');
        // Fill the username field
        if (targetField) {
          targetField.value = username;
          // Trigger input event to notify the page of changes
          targetField.dispatchEvent(new Event('input', { bubbles: true }));
          targetField.dispatchEvent(new Event('change', { bubbles: true }));
        }
        // Remove notification
        document.body.removeChild(notification);
      });
    });
  }
  
  // Run detection when page is fully loaded
  window.addEventListener('load', detectLoginForms);
  
  // Also run when the DOM content is loaded (may be faster on some sites)
  document.addEventListener('DOMContentLoaded', detectLoginForms);
  
  // Add CSS for the notification
  const style = document.createElement('style');
  style.textContent = `
    .daws-notification-header {
      display: flex;
      align-items: center;
      padding: 10px;
      border-bottom: 1px solid #eee;
      background: #f8f9fa;
      border-radius: 8px 8px 0 0;
    }
    
    .daws-notification-header img {
      width: 24px;
      height: 24px;
      margin-right: 8px;
    }
    
    .daws-notification-header h3 {
      margin: 0;
      flex-grow: 1;
      font-size: 16px;
    }
    
    .daws-close-btn {
      background: none;
      border: none;
      font-size: 20px;
      cursor: pointer;
      color: #666;
    }
    
    .daws-notification-content {
      padding: 10px;
    }
    
    .daws-credential-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    
    .daws-credential-item {
      display: flex;
      align-items: center;
      padding: 8px;
      border-bottom: 1px solid #eee;
      justify-content: space-between;
    }
    
    .daws-credential-item:last-child {
      border-bottom: none;
    }
    
    .daws-username {
      color: #666;
      font-size: 12px;
      margin: 0 8px;
    }
    
    .daws-fill-btn {
      background: #4f46e5;
      color: white;
      border: none;
      border-radius: 4px;
      padding: 4px 8px;
      cursor: pointer;
      font-size: 12px;
    }
  `;
  document.head.appendChild(style);